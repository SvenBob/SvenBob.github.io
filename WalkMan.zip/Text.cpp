
// Text.cpp: implementation of the CText class.
//
//////////////////////////////////////////////////////////////////////

#include "Text.h"
#include "stdio.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CText::CText()
{
	ControlInfoL1="Use array key to control the robot";
	ControlInfoL2="Use 'a' key to view in full screen,'r' to return, use 'ESC' to exit";
	SceneInfoL1="You can walk into the house through the door which is on the front of you";
	SceneInfoL2="Gray lines describe the ceiling and floor";
	SceneInfoL3="Red lines describe the walls";
	SceneInfoL4="Green lines describe the robot";
}

CText::~CText()
{

}

void CText::ShowText()
{
	int i=0;
	glColor3f(0.0,1.0,1.0);
	setOrthoProjection();
	glPushMatrix();
		glLoadIdentity();
		//glRasterPos2i(20, 60);
		glRasterPos2f(10, 20);
		while(ControlInfoL1[i]!=NULL)
		{
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15,ControlInfoL1[i]);
			i++;
		}
		//glRasterPos2i(20, 40);
		glRasterPos2f(10, 40);
		i=0;
		while(ControlInfoL2[i]!=NULL)
		{
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15,ControlInfoL2[i]);
			i++;
		}
		glRasterPos2f(10, 60);
		i=0;
		while(SceneInfoL1[i]!=NULL)
		{
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15,SceneInfoL1[i]);
			i++;
		}
		glRasterPos2f(10, 80);
		i=0;
		while(SceneInfoL2[i]!=NULL)
		{
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15,SceneInfoL2[i]);
			i++;
		}
		glRasterPos2f(10, 100);
		i=0;
		while(SceneInfoL3[i]!=NULL)
		{
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15,SceneInfoL3[i]);
			i++;
		}
		glRasterPos2f(10, 120);
		i=0;
		while(SceneInfoL4[i]!=NULL)
		{
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15,SceneInfoL4[i]);
			i++;
		}
	glPopMatrix();
	resetPerspectiveProjection();
	//glMatrixMode(GL_MODELVIEW);
}

void CText::setOrthoProjection()
{
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, width, 0, height);
	glScalef(1, -1, 1);
	glTranslatef(0, -height, 0);
	glMatrixMode(GL_MODELVIEW);
	//glLoadIdentity();
}

void CText::resetPerspectiveProjection()
{
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}
