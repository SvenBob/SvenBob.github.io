// Scene.cpp: implementation of the CScene class.
//
//////////////////////////////////////////////////////////////////////

#include "Scene.h"
#include "gl/glut.h"
#include "math.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CScene::CScene()
{
	angle=-90.0;
	PI=3.14159;
	rad=float(PI*angle/180.0);
	Eye[0]=0.0;				//�۾�ǰ��65����λ��λ��
	Eye[1]=40.0;
	Eye[2]=300.0;
	Look[0]=0.0;			//�۲�Ŀ����λ��
	Look[1]=40.0;
	Look[2]=200.0;
	Robot.Position[0]=Eye[0];   //�����˵�λ��
	Robot.Position[1]=30;
	Robot.Position[2]=Eye[2];
	WalkOrNot=0;
}

CScene::~CScene()
{

}

void CScene::DrawScene(void)
{
	Robot.Position[0]=Eye[0];
	Robot.Position[1]=30;
	Robot.Position[2]=Eye[2];
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	gluLookAt(Eye[0]-65*cos(rad),Eye[1],Eye[2]-65*sin(rad),				//���۾���λ�������ڻ����˺���65����λ��ʵ�ָ�������
		Look[0],Look[1],Look[2],
		0.0,1.0,0.0);
	glPushMatrix();							//��ʼ���Ƴ���
		glColor3f(0.45,0.45,0.45);
		glTranslatef(0.0,-5.0,0.0);
		glScalef(300,10,300);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(0.0,50.0,-145.0);
		glScalef(300,100,10);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(-145.0,50.0,0.0);
		glScalef(10,100,300);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(145.0,30.0,85.0);
		glScalef(10,60,130);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(145.0,30.0,-85.0);
		glScalef(10,60,130);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(145.0,80.0,0.0);
		glScalef(10,40,300);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(0.0,80.0,145.0);
		glScalef(300,40,10);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(-85.0,30.0,145.0);
		glScalef(130,60,10);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(85.0,30.0,145.0);
		glScalef(130,60,10);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(0.45,0.45,0.45);
		glTranslatef(-10.0,105.0,0.0);
		glScalef(320,10,320);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(0.45,0.45,0.45);
		glTranslatef(300.0,-5.0,0.0);
		glScalef(300,10,300);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(0.45,0.45,0.45);
		glTranslatef(310.0,105.0,0.0);
		glScalef(320,10,320);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(300.0,50.0,145.0);
		glScalef(300,100,10);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(300.0,50.0,-145.0);
		glScalef(300,100,10);
		glutWireCube(1.0);
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,0.0,0.0);
		glTranslatef(445.0,50.0,0.0);
		glScalef(10,100,300);
		glutWireCube(1.0);
	glPopMatrix();					//���Ƴ�������
	glPushMatrix();
		glTranslatef(Robot.Position[0],30,Robot.Position[2]);  //���û�����λ��
		glRotatef(-angle,0.0,1.0,0.0);
		glScalef(0.7,0.7,0.7);
		if(WalkOrNot==0)
			Robot.DrawRobot();			//���뾲ֹ������
		if(WalkOrNot==1)
			Robot.DrawWalkedRobot();	//�����˶��Ļ�����
	glPopMatrix();
}

void CScene::InitRobot()			//��ʼ��������״̬����
{
	Robot.flagS=1;
	Robot.flagL=1;
	Robot.shoulder=0;
	Robot.leg=0;
}

