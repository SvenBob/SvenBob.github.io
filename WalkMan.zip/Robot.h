// Robot.h: interface for the CRobot class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ROBOT_H__1F3EC57F_B17A_4733_8E73_6C99F376C2BD__INCLUDED_)
#define AFX_ROBOT_H__1F3EC57F_B17A_4733_8E73_6C99F376C2BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "gl/glut.h"

class CRobot
{
public:
	int flagL;
	int flagS;
	int shoulder;
	int leg;
	void DrawWalkedRobot(void);
	float Position[3];
	void DrawRobot(void);
	CRobot();
	virtual ~CRobot();

};

#endif // !defined(AFX_ROBOT_H__1F3EC57F_B17A_4733_8E73_6C99F376C2BD__INCLUDED_)

