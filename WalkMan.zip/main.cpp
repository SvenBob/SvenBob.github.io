/*robot has five animated action*/
/* rotate base : click mouse left button (to stop, click again) */
/* click the mouse right button to show the menu */
/* rotate torso : press torso (to stop, press torso again) */
/* rotate arm : press arms (to stop, press arms again) */
/* rotate legs: press legs (to stop, press legs again) */
/* punch: press punch (to move back, press punch again) */


/* I added some specific detail such as joint, neck, hat, shoes and some lighting set                                                      */



#include <stdlib.h>
#include <GL/glut.h>



#define TORSO_WIDTH 1.0
#define TORSO_LENGTH 2.0
#define TORSO_HEIGHT 4.0
#define HEAD_RADIUS 0.8
#define NECK_RADIUS 0.3
#define HAT_RADIUS 0.6
#define HAT_HEIGHT 0.9
#define LOWER_ARM_WIDTH  0.3
#define LOWER_ARM_HEIGHT 2.0
#define UPPER_ARM_WIDTH  0.4
#define UPPER_ARM_HEIGHT 1.7
#define LOWER_LEG_WIDTH  0.6
#define LOWER_LEG_HEIGHT 3.0
#define UPPER_LEG_WIDTH  1.0
#define UPPER_LEG_HEIGHT 2.5


GLUquadricObj *p;   // pointer to quadric object
GLint menu_id;
GLint n=-1;
GLfloat theta[5] = {0.0, 0.0, 0.0, 0.0,0.0};
GLfloat gamma[4] = {0.0, 0.0, 0.0, 0.0};//

GLboolean tor = GL_FALSE;
GLboolean leg = GL_FALSE;
GLboolean arm = GL_FALSE;
GLboolean reset = GL_FALSE;
GLboolean punch = GL_FALSE;
GLboolean tur = GL_TRUE;

GLint t_direction = 1;
GLint a_direction = -1;
GLint l_direction = 1;

void hat()
{
  glPushMatrix();
   glColor3f(0.0,0.0,0.0);
   glTranslatef(0.0,0.5*HAT_HEIGHT,0.0);
   glRotatef(-90,1,0,0);
   gluCylinder(p,HAT_RADIUS,HAT_RADIUS,HAT_HEIGHT,32,16);

   glDisable(GL_CULL_FACE);   // make a smooth edge transition
   gluDisk(p,HAT_RADIUS,HAT_RADIUS+0.3,26,13);
   glEnable(GL_CULL_FACE);

   glTranslatef(0.0,0.0,HAT_HEIGHT);
   gluDisk(p,0,HAT_RADIUS,26,13);

  glPopMatrix();
}

void torso()
{
  glPushMatrix();
    glTranslatef(0.0, 0.5*TORSO_HEIGHT,0.0);
    glScalef(TORSO_LENGTH, TORSO_HEIGHT, TORSO_WIDTH);
    glutSolidCube(1.0);
  glPopMatrix();
}

void head()
{
  glPushMatrix();
    glScalef(HEAD_RADIUS, HEAD_RADIUS, HEAD_RADIUS);
    gluSphere(p, HEAD_RADIUS, 15, 15);
  glPopMatrix();
}

void neck()
{
  glPushMatrix();
    glRotatef(-90,1,0,0);
    gluCylinder(p,NECK_RADIUS,NECK_RADIUS,HEAD_RADIUS,32,32);
  glPopMatrix();
}


void lower_arm()
{
  glPushMatrix();
    glTranslatef(0.0,-0.5*LOWER_ARM_HEIGHT, 0.0);
    glScalef(LOWER_ARM_WIDTH, LOWER_ARM_HEIGHT, LOWER_ARM_WIDTH);
    glutSolidCube(1.0);
  glPopMatrix();
}

void upper_arm()
{
  glPushMatrix();
    glTranslatef(0.0,-0.5*UPPER_ARM_HEIGHT, 0.0);
    glScalef(UPPER_ARM_WIDTH, UPPER_ARM_HEIGHT, UPPER_ARM_WIDTH);
    glutSolidCube(1.0);
  glPopMatrix();

}

void lower_leg()
{
  glPushMatrix();
    gluSphere(p, LOWER_LEG_WIDTH/2, 15, 15); //add a joint
    glTranslatef(0.0,-LOWER_LEG_HEIGHT, 0.0);
    glRotatef(-90,1,0,0);
    gluCylinder(p,LOWER_LEG_WIDTH/2, LOWER_LEG_WIDTH/2, LOWER_LEG_HEIGHT,32,32);
    glColor3f(0.0,0.0,0.0);

    glRotatef(-90,1,0,0);
    glTranslatef(0.0, 0.0,0.5*LOWER_LEG_WIDTH);
    glScalef(LOWER_LEG_WIDTH, LOWER_LEG_WIDTH/2, 2*LOWER_LEG_WIDTH);
    glutSolidCube(1.0);
  glPopMatrix();
}

void upper_leg()
{
  glPushMatrix();
    gluSphere(p, UPPER_LEG_WIDTH/2, 15, 15);  //add a joint
    glTranslatef(0.0,-UPPER_LEG_HEIGHT, 0.0);
    glRotatef(-90,1,0,0);
    gluCylinder(p, LOWER_LEG_WIDTH/2, UPPER_LEG_WIDTH/2,UPPER_LEG_HEIGHT,32,32);
  glPopMatrix();
}

void display()
{

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glMatrixMode(GL_MODELVIEW);

  glEnable(GL_COLOR_MATERIAL);  // lighting set

  glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);

  glLoadIdentity();
  gluLookAt(1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);


//start of whole body
  glRotatef(theta[3], 0.0, 1.0, 0.0);
  glTranslatef(0,-LOWER_LEG_HEIGHT*theta[2]/90,0); // since the kneeling,
  glTranslatef(0,-UPPER_LEG_HEIGHT*(gamma[0]/90),0); // since the move,

  glPushMatrix(); //start of upper body

    glRotatef(-theta[0], 1.0, 0.0, 0.0);
    glPushMatrix();
      glColor3f (1.0, 0.0, 0.0);
      torso();
    glPopMatrix();


    glPushMatrix();
      glTranslatef(0,TORSO_HEIGHT+HEAD_RADIUS,0);
      glColor3f(0.92,0.8,0.54);
      head();
      glTranslatef(0,-HEAD_RADIUS,0);
      neck();
    glPopMatrix();

    glPushMatrix();
      glTranslatef(0,TORSO_HEIGHT+0.85*HEAD_RADIUS,0);
      glColor3f(0.0,0.0,0.0);
      hat();
    glPopMatrix();

/////////////////////////left_arm////////////////////

    glPushMatrix();

      glColor3f (1.0, 0.0, 0.0);
      glTranslatef(0.5*(TORSO_LENGTH+UPPER_ARM_WIDTH),0.85*TORSO_HEIGHT, 0.0);
      glRotatef(gamma[2], -1.0, 0.0, 0.0); // for the punch
      glRotatef(theta[1], 1.0, 0.0, 0.0); //for the arm
      upper_arm();


      glTranslatef(0.0,-UPPER_ARM_HEIGHT, 0.0);
      glRotatef(theta[1], 1.0, 0.0, 0.0); //for the arm
      glRotatef(2*gamma[2], 1.0, 0.0, 0.0); // for the punch
      glColor3f(0.92,0.8,0.54); //the skin color
      lower_arm();
    glPopMatrix();
///////////////////////right_arm/////
    glPushMatrix();
      glColor3f (1.0, 0.0, 0.0);
      glTranslatef(-0.5*(TORSO_LENGTH+UPPER_ARM_WIDTH),0.85*TORSO_HEIGHT, 0.0);
      glRotatef(2*gamma[2], 1.0, 0.0, 0.0); //for the punch
      glRotatef(theta[1], 1.0, 0.0, 0.0);
      upper_arm();

      glTranslatef(0.0,-UPPER_ARM_HEIGHT, 0.0);
      glRotatef(gamma[3], 1.0, 0.0, 0.0); // for the punch
      glRotatef(theta[1], 1.0, 0.0, 0.0); // for the arm click
      glColor3f(0.92,0.8,0.54);
      lower_arm();
    glPopMatrix();

  glPopMatrix();// end of upper body

//////////////////right leg /////////////////
  glPushMatrix();
    glColor3f (1.0, 1.0, 0.0);
    glTranslatef(0.5*UPPER_LEG_WIDTH,0.0, 0.0);
    glRotatef(gamma[0], 1.0, 0.0, 1.0);
    upper_leg();

    glTranslatef(0.0,-UPPER_LEG_HEIGHT, 0.0);
    glRotatef(-gamma[1], 1.0, 0.0, 1.0);
    glRotatef(-theta[2], 1.0, 0.0, 0.0);
    glColor3f(0.92,0.8,0.54);
    lower_leg();
  glPopMatrix();

//////////////////left leg ////////////////////
  glPushMatrix();
    glRotatef(-theta[0], 1.0, 0.0, 0.0);
    glColor3f (1.0, 1.0, 0.0);
    glTranslatef(-0.5*UPPER_LEG_WIDTH,0.0, 0.0);
    glRotatef(gamma[0], 1.0, 0.0, -1.0);
    upper_leg();

    glTranslatef(0.0,-UPPER_LEG_HEIGHT, 0.0);
    glRotatef(-gamma[1], 1.0, 0.0, -1.0);
    glRotatef(-theta[2], 1.0, 0.0, 0.0);
    glColor3f(0.92,0.8,0.54);
    lower_leg();
  glPopMatrix();//end of legs

//end of whole body

  glutSwapBuffers();
}


void init()
{
  GLfloat ambientLight[]={1.0,1.0,0.5,1.0 };

  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE); //ignore the inside calculating
  glEnable(GL_CCW); // counter clock wise

  glEnable(GL_LIGHTING);  // start lighting

  glLightModelfv(GL_LIGHT_MODEL_AMBIENT,ambientLight);

  glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);

  glClearColor(1.0f, 0.8f, 0.8f, 1.0f);
  p = gluNewQuadric();

}

void reshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w <= h)
        glOrtho(-10.0, 10.0, -10.0 * (GLfloat) h / (GLfloat) w,
            10.0 * (GLfloat) h / (GLfloat) w, -10.0, 10.0);
    else
        glOrtho(-10.0* (GLfloat) w / (GLfloat) h,
            10.0* (GLfloat) w / (GLfloat) h, -10.0, 10.0, -10.0, 10.0);
    glMatrixMode(GL_MODELVIEW);
    glutPostRedisplay();
}

void menu(GLint menu_id)
{
  glutAddMenuEntry("torso",1);
  glutAddMenuEntry("arms",2);
  glutAddMenuEntry("legs",3);
  glutAddMenuEntry("reset",4);
  glutAddMenuEntry("punch",5);

  glutAttachMenu(GLUT_RIGHT_BUTTON);
}

void MenuFunc(int data)
{
   switch(data)
   {
        case 1:
        tor =! tor;
        break;
        case 2:
        arm =! arm;
        break;
        case 3:
        leg =! leg;
        break;
        case 4:
        reset =! reset;
        break;
        case 5:
        punch =! punch;
        break;
   }
}

void mymouse(GLint button, GLint state, GLint x, GLint y) {

	if (button==GLUT_LEFT_BUTTON && state==GLUT_DOWN) {
		tur = !tur;
	}
}

void idle()
{
  if (tor) {
    if (t_direction > 0) {
       theta[0] += 0.05;
       if (theta[0] > 70) {
          t_direction = -1;
          theta[0] -= 0.02;
       }
    }
    else {
       theta[0] -= 0.05;
       if (theta[0] < 0) {
          t_direction = 1;
          theta[0] += 0.05;
       }
    }
  }
  if (arm) {
    if (a_direction > 0) {
       theta[1] += 0.05;
       if (theta[1] > 90) {
          a_direction = -1;
          theta[1] -= 0.05;
       }
    }
    else {
       theta[1] -= 0.05;
       if (theta[1] < 0) {
          a_direction = 1;
          theta[1] += 0.05;
       }
    }
  }
  if (leg) {
    if (l_direction > 0) {
       theta[2] += 0.05;
       if (theta[2] > 90) {
          l_direction = -1;
          theta[2] -= 0.05;
       }
    }
    else {
       theta[2] -= 0.05;
       if (theta[2] < 0) {
          l_direction = 1;
          theta[2] += 0.05;
       }
    }
  }
  /*
this part above is to make sure every animation will be endless until the certain button be clicked again

*/
  if (tur) {
    theta[3] += 0.1;
    if (theta[3] > 360) theta[3] -= 360;
  }

  if (reset){
     theta[0] = 0.0;
     theta[1] = 0.0;
     theta[2] = 0.0;
     theta[3] = 0.0;

     tor = GL_FALSE;
     leg = GL_FALSE;
     arm = GL_FALSE;
     reset = GL_FALSE;
     tur = GL_FALSE;

     n= -1;
  }
  /*
  the reset part cannot reset the move of punch, and the punch action, which is not as others are loops, will move back when the punch menu been clicked again.
  */
  if (punch) {

       gamma[0] += 0.02;
       gamma[1] += 0.02;
       if (gamma[0] > 45) {
          gamma[0] = 45.0;
          gamma[1] = 45.0;
       }
       gamma[2] += 0.03;

       if (gamma[2] > 30) gamma[2] = 30.0;

       if (a_direction > 0) {
          gamma[3] += 0.12;
          if (gamma[3] > 90) {
             a_direction = -1;
             gamma[3] -= 0.12;
          }
        }
        else {
           gamma[3] -= 0.12;
           if (gamma[3] < 0) {

              gamma[3] = 0.0;
           }
        }




  }
  else if (!punch){

       gamma[0] -= 0.02;
       gamma[1] -= 0.02;
       if (gamma[0] < 0) {
          gamma[0] = 0.0;
          gamma[1] = 0.0;
       }
       gamma[2] -= 0.03;

       if (gamma[2] < 0) gamma[2] = 0.0;

       if (a_direction < 0) {
          gamma[3] -= 0.12;
          if (gamma[3] < 0) {
             a_direction = -1;
             gamma[3] += 0.12;
          }
        }
        else {
           gamma[3] += 0.12;
           if (gamma[3] > 0) {

              gamma[3] = 0.0;
           }
        }



  }



  glutPostRedisplay();
}


int main(int argc, char **argv)
{
  glutInit(&argc, argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize(500, 500);
  glutCreateWindow("humanoid");



  menu_id=glutCreateMenu(MenuFunc);
  menu(menu_id);
  glutMouseFunc(mymouse);
  glutIdleFunc(idle);
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  //glEnable(GL_DEPTH_TEST); /* Enable hidden-surface removal */

  init();
  glutMainLoop();
}

