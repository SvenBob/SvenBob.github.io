// Scene.h: interface for the CScene class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCENE_H__55063D87_1D05_4493_B752_7E9FAE03492C__INCLUDED_)
#define AFX_SCENE_H__55063D87_1D05_4493_B752_7E9FAE03492C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Robot.h"

class CScene
{
public:
	void InitRobot(void);
	float PI;
	float rad;
	float Look[3];
	float Eye[3];
	CScene();
	virtual ~CScene();
	void DrawScene(void);
	float angle;
	CRobot Robot;
	int WalkOrNot;
private:

};

#endif // !defined(AFX_SCENE_H__55063D87_1D05_4493_B752_7E9FAE03492C__INCLUDED_)

