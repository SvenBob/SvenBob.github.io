#include"windows.h"
#include <stdlib.h>
#include <GL/glut.h>

#define TORSO_WIDTH 1.0
#define TORSO_LENGTH 2.0
#define TORSO_HEIGHT 4.0
#define HEAD_RADIUS 0.8
#define NECK_RADIUS 0.3
#define HAT_RADIUS 0.6
#define HAT_HEIGHT 0.9
#define LOWER_ARM_WIDTH  0.3
#define LOWER_ARM_HEIGHT 2.0
#define UPPER_ARM_WIDTH  0.4
#define UPPER_ARM_HEIGHT 1.7
#define LOWER_LEG_WIDTH  0.6
#define LOWER_LEG_HEIGHT 3.0
#define UPPER_LEG_WIDTH  1.0
#define UPPER_LEG_HEIGHT 2.5
