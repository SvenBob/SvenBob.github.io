
#include "gl/glut.h"
#include "math.h"
#include "Scene.h"
#include "Text.h"
#pragma comment( linker, "/subsystem:\"windows\" /entry:\"mainCRTStartup\"" )

int w,h;
CScene House;
CText Text;

void Init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel (GL_FLAT);
}

void renderScene(void)
{
	House.DrawScene();
	Text.ShowText();
	glutSwapBuffers();
}

void reshape (int w1, int h1)
{
	w=w1;
	h=h1;
	Text.width=w1;
	Text.height=h1;
	glViewport(0,0,(GLsizei)w1,(GLsizei)h1);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(65.0,(GLfloat)w1/(GLfloat)h1,1.0,500.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef (0.0, 0.0, -500.0);
}

void keyboard(unsigned char key,int x,int y)  // Create Keyboard Function
{
	switch(key){
		case 'a':
			glutFullScreen();
			break;
		case 'r':
			glutPositionWindow(100,100);
			glutReshapeWindow(800,600);
			break;
		case 27:        // When Escape Is Pressed...
			exit(0);   // Exit The Program
			break;        // Ready For Next Case
		default:        // Now Wrap It Up
			break;
  }
}

void Control(GLint specialKey,GLint xMouse,GLint yMouse)
{
	switch(specialKey){
		case GLUT_KEY_LEFT:			//'a' turn left
			House.WalkOrNot=0;			//���ñ�־����Ϊ�����˾�ֹ״̬
			House.InitRobot();			//�ڲ���ǰ����ʱ�ָ������˾�ֹ����
			House.rad=float(House.PI*House.angle/180.0);
			House.angle-=1;
			House.Look[0]=float(House.Eye[0]+1000*cos(House.rad));			//ʵ��ת��
			House.Look[2]=float(House.Eye[2]+1000*sin(House.rad));
			renderScene();
			break;
		case GLUT_KEY_RIGHT:			//'d' turn right
			House.WalkOrNot=0;
			House.InitRobot();
			House.rad=float(House.PI*House.angle/180.0);
			House.angle+=1;
			House.Look[0]=float(House.Eye[0]+1000*cos(House.rad));
			House.Look[2]=float(House.Eye[2]+1000*sin(House.rad));
			renderScene();
			break;
		case GLUT_KEY_DOWN:			//'s' go back
			House.WalkOrNot=1;
			House.rad=float(House.PI*House.angle/180.0);
			House.Eye[2]-=(float)sin(House.rad)*1.0;			//ʵ������˶�
			House.Eye[0]-=(float)cos(House.rad)*1.0;
			if((House.Eye[2]<=160&&House.Eye[2]>=130&&House.Eye[0]>=-160&&House.Eye[0]<=-8)||
				(House.Eye[2]<=160&&House.Eye[2]>=130&&House.Eye[0]>=8&&House.Eye[0]<=460)||
				(House.Eye[2]>=-160&&House.Eye[2]<=-130&&House.Eye[0]>=-160&&House.Eye[0]<=460)||
				(House.Eye[2]>=-160&&House.Eye[2]<=160&&House.Eye[0]>=-160&&House.Eye[0]<=-130)||
				(House.Eye[2]>=-160&&House.Eye[2]<=160&&House.Eye[0]<=460&&House.Eye[0]>=430)||
				(House.Eye[2]>=-160&&House.Eye[2]<=-8&&House.Eye[0]<=160&&House.Eye[0]>=130)||
				(House.Eye[2]>=8&&House.Eye[2]<=160&&House.Eye[0]<=160&&House.Eye[0]>=130))
			{
				House.Eye[2]+=(float)sin(House.rad)*1.0;		//һ�������ϰ�����ȡ������˶������ڲ��ܽ����ϰ�����
				House.Eye[0]+=(float)cos(House.rad)*1.0;
			}
			House.Look[0]=float(House.Eye[0]+1000*cos(House.rad));
			House.Look[2]=float(House.Eye[2]+1000*sin(House.rad));
			renderScene();
			break;
		case GLUT_KEY_UP:				//'w' go front
			House.WalkOrNot=1;
			House.rad=float(House.PI*House.angle/180.0);
			House.Eye[2]+=(float)sin(House.rad)*1.0;			//ʵ����ǰ�˶�
			House.Eye[0]+=(float)cos(House.rad)*1.0;
			if((House.Eye[2]<=160&&House.Eye[2]>=130&&House.Eye[0]>=-160&&House.Eye[0]<=-8)||
				(House.Eye[2]<=160&&House.Eye[2]>=130&&House.Eye[0]>=8&&House.Eye[0]<=460)||
				(House.Eye[2]>=-160&&House.Eye[2]<=-130&&House.Eye[0]>=-160&&House.Eye[0]<=460)||
				(House.Eye[2]>=-160&&House.Eye[2]<=160&&House.Eye[0]>=-160&&House.Eye[0]<=-130)||
				(House.Eye[2]>=-160&&House.Eye[2]<=160&&House.Eye[0]<=460&&House.Eye[0]>=430)||
				(House.Eye[2]>=-160&&House.Eye[2]<=-8&&House.Eye[0]<=160&&House.Eye[0]>=130)||
				(House.Eye[2]>=8&&House.Eye[2]<=160&&House.Eye[0]<=160&&House.Eye[0]>=130))
			{
				House.Eye[2]-=(float)sin(House.rad)*1.0;		//һ�������ϰ�����ȡ������˶������ڲ��ܽ����ϰ�����
				House.Eye[0]-=(float)cos(House.rad)*1.0;
			}
			House.Look[0]=float(House.Eye[0]+1000*cos(House.rad));
			House.Look[2]=float(House.Eye[2]+1000*sin(House.rad));
			renderScene();
			break;
		default:        // Now Wrap It Up
			break;
	}
}

void main(int argc,char** argv)
{
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
	glutInitWindowPosition(100,100);
	glutInitWindowSize(800,600);
	glutCreateWindow("glutRobotInScene");
	Init();
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(Control);
	glutDisplayFunc(renderScene);
	glutReshapeFunc(reshape);
	//glutIdleFunc(renderScene);
	glutMainLoop();
}
