/*----------------------------------------------------------
* COSC363  Ray Tracer
*
*  The sphere class
*  This is a subclass of Object, and hence implements the
*  methods intersect() and normal().
-------------------------------------------------------------*/
#include"windows.h"
#include "Sphere.h"
#include <math.h>

//TEMP
#include <iostream>
#include <cmath>
#include <vector>
#include "Vector.h"
#include "Cylinder.h"
#include "Sphere.h"
#include "Plane.h"
#include "Color.h"
#include "Object.h"
#include "TextureBMP.h"
#include <GL/glut.h>
using namespace std;

/**
* Sphere's intersection method.  The input is a ray (pos, dir).
*/
float Sphere::intersect(Vector pos, Vector dir)
{
  Vector vdif = pos - center;
  float b = dir.dot(vdif);
  float len = vdif.length();
  float c = len*len - radius*radius;
  float delta = b*b - c;

	if(fabs(delta) < 0.001) {
    return -1.0;
  }
  if(delta < 0.0) {
    return -1.0;
  }

  float t1 = -b - sqrt(delta);
  float t2 = -b + sqrt(delta);
  if(fabs(t1) < 0.001 )
  {
      if (t2 > 0) return t2;
      else t1 = -1.0;
  }
  if(fabs(t2) < 0.001 ) t2 = -1.0;

	return (t1 < t2)? t1: t2;
}

/**
* Returns the unit normal vector at a given point.
* Assumption: The input point p lies on the sphere.
*/
Vector Sphere::normal(Vector p)
{
    Vector n = p - center;
    n.normalise();
    return n;
}

